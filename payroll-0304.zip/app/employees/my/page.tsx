'use client'

import { useEffect, useState } from 'react'
import { useSession } from 'next-auth/react'
import { supabase } from '@/lib/supabase'

import UploadDocument from '@/components/UploadDocument'
import EmployeeDocumentsList from '@/components/EmployeeDocumentsList'
import EmployeeOnboardingChecklist from '@/components/EmployeeOnboardingChecklist'
import EmployeeHRChecklist from '@/components/EmployeeHRChecklist'

import ApplicationPersonalSection from '@/components/forms/ApplicationPersonalSection'
import ApplicationEducationSection from '@/components/forms/ApplicationEducationSection'
import PreviousEmploymentVerificationForm from '@/components/forms/PreviousEmploymentVerificationForm'
import ConfidentialityAgreementForm from '@/components/forms/ConfidentialityAgreementForm'
import AgreementForProfessionalServicesForm from '@/components/forms/AgreementForProfessionalServicesForm'
import SystemAccessRequestForm from '@/components/forms/SystemAccessRequestForm'
import SecurityAgreementForm from '@/components/forms/SecurityAgreementForm'
import DrugAlcoholConsentForm from '@/components/forms/DrugAlcoholConsentForm'
import DirectDepositAuthorizationForm from '@/components/forms/DirectDepositAuthorizationForm'
import PersonnelHandbookAcknowledgementForm from '@/components/forms/PersonnelHandbookAcknowledgementForm'
import ApplicationSignatureSection from '@/components/forms/ApplicationSignatureSection'

export default function MyEmployeePage() {
  const { data: session, status } = useSession()
  const [employeeId, setEmployeeId] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchEmployee = async () => {
      if (status !== 'authenticated' || !session?.user?.email) return

      const { data, error } = await supabase
        .from('employees')
        .select('id')
        .eq('email', session.user.email)
        .eq('ready_for_payroll', false)
        .single()

      if (data) setEmployeeId(data.id)
      setLoading(false)
    }

    fetchEmployee()
  }, [session, status])

  if (loading) return <p className="p-4">Cargando...</p>
  if (!employeeId) return <p className="p-4">No tienes acceso o ya estás aprobado para payroll.</p>

  return (
    <div className="p-6 space-y-8 max-w-4xl mx-auto">
      <h1 className="text-2xl font-bold">Mi Expediente de Ingreso</h1>

      {/* 📝 Datos personales */}
      <ApplicationPersonalSection employeeId={employeeId} />

      {/* 🎓 Educación y experiencia laboral */}
      <ApplicationEducationSection employeeId={employeeId} />

      {/* 🧾 Verificación de empleo previo */}
      <PreviousEmploymentVerificationForm employeeId={employeeId} />

      {/* 📄 Acuerdo de confidencialidad */}
      <ConfidentialityAgreementForm employeeId={employeeId} />

      {/* 📄 Acuerdo de servicios profesionales */}
      <AgreementForProfessionalServicesForm employeeId={employeeId} />

      {/* 🖥️ Solicitud de acceso a sistemas */}
      <SystemAccessRequestForm employeeId={employeeId} />

      {/* 🔐 Acuerdo de seguridad informática */}
      <SecurityAgreementForm employeeId={employeeId} />

      {/* 🧪 Consentimiento de drogas y alcohol */}
      <DrugAlcoholConsentForm employeeId={employeeId} />

      {/* 🏦 Autorización de depósito directo */}
      <DirectDepositAuthorizationForm employeeId={employeeId} />
      <UploadDocument employeeId={employeeId} type="void_check" />

      {/* 📘 Confirmación del Manual del Empleado */}
      <PersonnelHandbookAcknowledgementForm employeeId={employeeId} />

      {/* 📤 Subida de documentos */}
      <UploadDocument employeeId={employeeId} type="id" />
      <UploadDocument employeeId={employeeId} type="w9" />
      <UploadDocument employeeId={employeeId} type="license" />
      <UploadDocument employeeId={employeeId} type="i9" />

      {/* 📂 Documentos subidos */}
      <EmployeeDocumentsList employeeId={employeeId} />

      {/* 📋 Checklist general */}
      <EmployeeOnboardingChecklist employeeId={employeeId} />

      {/* 📋 Checklist de RRHH (solo lectura) */}
      <EmployeeHRChecklist employeeId={employeeId} isEditable={false} />

      {/* ✍️ Firma final del expediente */}
      <ApplicationSignatureSection employeeId={employeeId} />
    </div>
  )
}