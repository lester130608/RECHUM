'use client'

import HRList from '@/components/HRList'

export default function EmployeesHRPage() {
  return (
    <div className="p-6">
      <HRList />
    </div>
  )
}