import "../styles/globals.css";
import SidebarAdmin from "@/components/SidebarAdmin";

export const metadata = {
  title: "Payroll",
  description: "Sistema de nómina",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-gray-100 text-gray-900">
        <div className="flex">
          <SidebarAdmin />
          <main className="flex-1">{children}</main>
        </div>
      </body>
    </html>
  );
}