export default function DashboardPage() {
  return (
    <div className="bg-green-200 text-xl p-10 rounded shadow">
      Dashboard cargando con Tailwind ✅
    </div>
  );
}