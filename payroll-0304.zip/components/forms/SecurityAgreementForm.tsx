'use client'

import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'

interface Props {
  employeeId: string
}

export default function SecurityAgreementForm({ employeeId }: Props) {
  const [accepted, setAccepted] = useState(false)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchStatus = async () => {
      const { data } = await supabase
        .from('security_agreements')
        .select('accepted')
        .eq('employee_id', employeeId)
        .single()

      if (data?.accepted) setAccepted(true)
      setLoading(false)
    }

    fetchStatus()
  }, [employeeId])

  const handleAccept = async () => {
    const { error } = await supabase
      .from('security_agreements')
      .upsert({
        employee_id: employeeId,
        accepted: true,
      }, { onConflict: ['employee_id'] })

    if (error) {
      alert('Error al registrar aceptación')
    } else {
      setAccepted(true)
      alert('✅ Acuerdo de seguridad aceptado')
    }
  }

  if (loading) return <p className="p-4">Cargando acuerdo...</p>

  return (
    <div className="space-y-4 border p-4 rounded">
      <h2 className="text-xl font-semibold">🔐 Acuerdo de Seguridad Informática</h2>

      <p className="text-sm text-gray-700">
        Al aceptar este acuerdo, reconozco que:
        <ul className="list-disc pl-5 mt-2">
          <li>No compartiré contraseñas ni accesos a los sistemas.</li>
          <li>No accederé a información sin autorización.</li>
          <li>Cumpliré con leyes estatales y federales sobre seguridad informática.</li>
          <li>Protegeré toda la información confidencial relacionada con empleados o pacientes.</li>
          <li>Entiendo que la divulgación del SSN es voluntaria pero puede ser necesaria para crear mis credenciales de acceso.</li>
        </ul>
      </p>

      {!accepted && (
        <button
          onClick={handleAccept}
          className="bg-blue-600 text-white px-4 py-2 rounded"
        >
          Acepto
        </button>
      )}

      {accepted && (
        <p className="text-green-600 font-medium">
          ✅ Ya aceptaste este acuerdo
        </p>
      )}
    </div>
  )
}