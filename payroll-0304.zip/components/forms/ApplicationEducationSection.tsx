'use client'

import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'

interface Props {
  employeeId: string
}

export default function ApplicationEducationSection({ employeeId }: Props) {
  const [form, setForm] = useState({
    high_school: '',
    hs_city: '',
    hs_grad_year: '',

    college: '',
    college_city: '',
    college_degree: '',
    college_grad_year: '',

    other_training: '',
    other_training_type: '',
    other_training_year: '',

    job1_employer: '',
    job1_position: '',
    job1_start: '',
    job1_end: '',
    job1_reason: '',

    job2_employer: '',
    job2_position: '',
    job2_start: '',
    job2_end: '',
    job2_reason: '',

    job3_employer: '',
    job3_position: '',
    job3_start: '',
    job3_end: '',
    job3_reason: '',
  })

  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchData = async () => {
      const { data } = await supabase
        .from('employment_applications')
        .select('*')
        .eq('employee_id', employeeId)
        .single()

      if (data) setForm((prev) => ({ ...prev, ...data }))
      setLoading(false)
    }

    fetchData()
  }, [employeeId])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setForm((prev) => ({ ...prev, [name]: value }))
  }

  const handleSave = async () => {
    const { error } = await supabase
      .from('employment_applications')
      .upsert({ ...form, employee_id: employeeId }, { onConflict: ['employee_id'] })

    if (error) {
      alert('Error al guardar: ' + error.message)
    } else {
      alert('Educación y experiencia guardadas ✅')
    }
  }

  if (loading) return <p className="p-4">Cargando...</p>

  return (
    <div className="space-y-4 border p-4 rounded">
      <h2 className="text-xl font-semibold">🎓 Educación y 💼 Experiencia Laboral</h2>

      {/* Educación */}
      <div>
        <label className="block mb-1 font-medium">Escuela secundaria</label>
        <input name="high_school" value={form.high_school} onChange={handleChange} className="w-full border px-3 py-2 mb-2 rounded" placeholder="Nombre" />
        <input name="hs_city" value={form.hs_city} onChange={handleChange} className="w-full border px-3 py-2 mb-2 rounded" placeholder="Ciudad" />
        <input name="hs_grad_year" value={form.hs_grad_year} onChange={handleChange} className="w-full border px-3 py-2 rounded" placeholder="Año de graduación" />
      </div>

      <div>
        <label className="block mb-1 font-medium">Universidad</label>
        <input name="college" value={form.college} onChange={handleChange} className="w-full border px-3 py-2 mb-2 rounded" placeholder="Nombre" />
        <input name="college_city" value={form.college_city} onChange={handleChange} className="w-full border px-3 py-2 mb-2 rounded" placeholder="Ciudad" />
        <input name="college_degree" value={form.college_degree} onChange={handleChange} className="w-full border px-3 py-2 mb-2 rounded" placeholder="Título obtenido" />
        <input name="college_grad_year" value={form.college_grad_year} onChange={handleChange} className="w-full border px-3 py-2 rounded" placeholder="Año de graduación" />
      </div>

      <div>
        <label className="block mb-1 font-medium">Otra formación</label>
        <input name="other_training" value={form.other_training} onChange={handleChange} className="w-full border px-3 py-2 mb-2 rounded" placeholder="Institución o centro" />
        <input name="other_training_type" value={form.other_training_type} onChange={handleChange} className="w-full border px-3 py-2 mb-2 rounded" placeholder="Tipo o especialidad" />
        <input name="other_training_year" value={form.other_training_year} onChange={handleChange} className="w-full border px-3 py-2 rounded" placeholder="Año" />
      </div>

      {/* Experiencia laboral */}
      {[1, 2, 3].map((i) => (
        <div key={i}>
          <label className="block mb-1 font-medium">Empleo #{i}</label>
          <input name={`job${i}_employer`} value={form[`job${i}_employer` as keyof typeof form]} onChange={handleChange} className="w-full border px-3 py-2 mb-2 rounded" placeholder="Nombre del empleador" />
          <input name={`job${i}_position`} value={form[`job${i}_position` as keyof typeof form]} onChange={handleChange} className="w-full border px-3 py-2 mb-2 rounded" placeholder="Cargo" />
          <input name={`job${i}_start`} value={form[`job${i}_start` as keyof typeof form]} onChange={handleChange} className="w-full border px-3 py-2 mb-2 rounded" placeholder="Fecha de inicio" />
          <input name={`job${i}_end`} value={form[`job${i}_end` as keyof typeof form]} onChange={handleChange} className="w-full border px-3 py-2 mb-2 rounded" placeholder="Fecha de salida" />
          <textarea name={`job${i}_reason`} value={form[`job${i}_reason` as keyof typeof form]} onChange={handleChange} className="w-full border px-3 py-2 rounded" placeholder="Motivo de salida" />
        </div>
      ))}

      <button
        onClick={handleSave}
        className="mt-4 bg-blue-600 text-white px-4 py-2 rounded"
      >
        Guardar sección
      </button>
    </div>
  )
}