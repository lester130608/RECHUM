'use client'

import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'

interface Props {
  employeeId: string
}

export default function PersonnelHandbookAcknowledgementForm({ employeeId }: Props) {
  const [acknowledged, setAcknowledged] = useState(false)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchStatus = async () => {
      const { data } = await supabase
        .from('personnel_handbook_ack')
        .select('acknowledged')
        .eq('employee_id', employeeId)
        .single()

      if (data?.acknowledged) setAcknowledged(true)
      setLoading(false)
    }

    fetchStatus()
  }, [employeeId])

  const handleAcknowledge = async () => {
    const { error } = await supabase
      .from('personnel_handbook_ack')
      .upsert({
        employee_id: employeeId,
        acknowledged: true,
      }, { onConflict: ['employee_id'] })

    if (error) {
      alert('Error al guardar confirmación')
    } else {
      setAcknowledged(true)
      alert('✅ Confirmación registrada correctamente')
    }
  }

  if (loading) return <p className="p-4">Cargando confirmación...</p>

  return (
    <div className="space-y-4 border p-4 rounded">
      <h2 className="text-xl font-semibold">📘 Acuse de Recibo del Manual del Empleado</h2>

      <p className="text-sm text-gray-700">
        Confirmo que he recibido, leído y comprendido el Manual del Empleado de DTT Coaching Services.
        Entiendo que mi empleo es “a voluntad” y que debo cumplir con las políticas, prácticas y procedimientos establecidos,
        incluyendo las normas de privacidad (HIPAA), ética profesional, y comportamiento laboral.
        Entiendo que estos documentos tienen valor legal y que cualquier violación puede llevar a acciones disciplinarias.
      </p>

      {!acknowledged && (
        <button
          onClick={handleAcknowledge}
          className="bg-blue-600 text-white px-4 py-2 rounded"
        >
          Acepto
        </button>
      )}

      {acknowledged && (
        <p className="text-green-600 font-medium">✅ Confirmación registrada</p>
      )}
    </div>
  )
}