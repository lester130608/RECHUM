'use client'

import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'

interface Props {
  employeeId: string
}

export default function DrugAlcoholConsentForm({ employeeId }: Props) {
  const [accepted, setAccepted] = useState(false)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchStatus = async () => {
      const { data } = await supabase
        .from('drug_alcohol_consent')
        .select('accepted')
        .eq('employee_id', employeeId)
        .single()

      if (data?.accepted) setAccepted(true)
      setLoading(false)
    }

    fetchStatus()
  }, [employeeId])

  const handleAccept = async () => {
    const { error } = await supabase
      .from('drug_alcohol_consent')
      .upsert({
        employee_id: employeeId,
        accepted: true,
      }, { onConflict: ['employee_id'] })

    if (error) {
      alert('Error al registrar aceptación')
    } else {
      setAccepted(true)
      alert('✅ Consentimiento registrado correctamente')
    }
  }

  if (loading) return <p className="p-4">Cargando consentimiento...</p>

  return (
    <div className="space-y-4 border p-4 rounded">
      <h2 className="text-xl font-semibold">🧪 Consentimiento para Pruebas de Drogas y Alcohol</h2>

      <p className="text-sm text-gray-700">
        Autorizo a DTT Coaching Services a realizar pruebas de detección de drogas y alcohol
        como parte del proceso de selección o durante mi empleo. Entiendo que los resultados
        podrán ser compartidos con la empresa y que la negativa a participar puede afectar
        mi elegibilidad o continuidad laboral. También libero a la empresa y a los laboratorios
        involucrados de cualquier responsabilidad relacionada con esta práctica.
      </p>

      {!accepted && (
        <button
          onClick={handleAccept}
          className="bg-blue-600 text-white px-4 py-2 rounded"
        >
          Acepto
        </button>
      )}

      {accepted && (
        <p className="text-green-600 font-medium">
          ✅ Consentimiento registrado
        </p>
      )}
    </div>
  )
}