'use client'

import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'

interface Props {
  employeeId: string
}

export default function PreviousEmploymentVerificationForm({ employeeId }: Props) {
  const [form, setForm] = useState({
    previous_employer: '',
    position_held: '',
    employment_start: '',
    employment_end: '',
    authorize_contact: false,
    signature: '',
    signed_date: '',
  })

  const [loading, setLoading] = useState(true)
  const [locked, setLocked] = useState(false)

  useEffect(() => {
    const fetchData = async () => {
      const { data } = await supabase
        .from('employment_verification')
        .select('*')
        .eq('employee_id', employeeId)
        .single()

      if (data) {
        setForm(data)
        if (data.signature && data.signed_date) setLocked(true)
      }

      setLoading(false)
    }

    fetchData()
  }, [employeeId])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value, type, checked } = e.target
    setForm((prev) => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }))
  }

  const handleSave = async () => {
    const { error } = await supabase
      .from('employment_verification')
      .upsert({ ...form, employee_id: employeeId }, { onConflict: ['employee_id'] })

    if (error) {
      alert('Error al guardar: ' + error.message)
    } else {
      alert('Formulario guardado correctamente ✅')
      setLocked(true)
    }
  }

  if (loading) return <p className="p-4">Cargando formulario...</p>

  return (
    <div className="space-y-4 border p-4 rounded">
      <h2 className="text-xl font-semibold">📄 Verificación de Empleo Previo</h2>

      <div>
        <label className="block mb-1">Nombre del empleador anterior</label>
        <input
          type="text"
          name="previous_employer"
          value={form.previous_employer}
          onChange={handleChange}
          disabled={locked}
          className="w-full border px-3 py-2 rounded"
        />
      </div>

      <div>
        <label className="block mb-1">Cargo desempeñado</label>
        <input
          type="text"
          name="position_held"
          value={form.position_held}
          onChange={handleChange}
          disabled={locked}
          className="w-full border px-3 py-2 rounded"
        />
      </div>

      <div className="flex gap-4">
        <div className="flex-1">
          <label className="block mb-1">Fecha de inicio</label>
          <input
            type="date"
            name="employment_start"
            value={form.employment_start}
            onChange={handleChange}
            disabled={locked}
            className="w-full border px-3 py-2 rounded"
          />
        </div>

        <div className="flex-1">
          <label className="block mb-1">Fecha de fin</label>
          <input
            type="date"
            name="employment_end"
            value={form.employment_end}
            onChange={handleChange}
            disabled={locked}
            className="w-full border px-3 py-2 rounded"
          />
        </div>
      </div>

      <div className="flex items-center gap-2">
        <input
          type="checkbox"
          name="authorize_contact"
          checked={form.authorize_contact}
          onChange={handleChange}
          disabled={locked}
        />
        <label>Autorizo a DTT a contactar a este empleador anterior</label>
      </div>

      <div>
        <label className="block mb-1">Firma (nombre completo)</label>
        <input
          type="text"
          name="signature"
          value={form.signature}
          onChange={handleChange}
          disabled={locked}
          className="w-full border px-3 py-2 rounded"
        />
      </div>

      <div>
        <label className="block mb-1">Fecha</label>
        <input
          type="date"
          name="signed_date"
          value={form.signed_date}
          onChange={handleChange}
          disabled={locked}
          className="w-full border px-3 py-2 rounded"
        />
      </div>

      {!locked && (
        <button
          onClick={handleSave}
          className="mt-4 bg-blue-600 text-white px-4 py-2 rounded"
        >
          Guardar y firmar
        </button>
      )}

      {locked && (
        <p className="text-green-700 font-medium">
          ✅ Formulario firmado el {form.signed_date}
        </p>
      )}
    </div>
  )
}