'use client'

import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'

interface Props {
  employeeId: string
}

export default function SystemAccessRequestForm({ employeeId }: Props) {
  const [role, setRole] = useState('')
  const [action, setAction] = useState('')
  const [supervisorApproval, setSupervisorApproval] = useState('')
  const [locked, setLocked] = useState(false)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetch = async () => {
      const { data } = await supabase
        .from('system_access_requests')
        .select('*')
        .eq('employee_id', employeeId)
        .single()

      if (data) {
        setRole(data.role || '')
        setAction(data.action || '')
        setSupervisorApproval(data.supervisor_approval || '')
        if (data.role && data.action) setLocked(true)
      }

      setLoading(false)
    }

    fetch()
  }, [employeeId])

  const handleSave = async () => {
    const { error } = await supabase
      .from('system_access_requests')
      .upsert({
        employee_id: employeeId,
        role,
        action,
        supervisor_approval: supervisorApproval
      }, { onConflict: ['employee_id'] })

    if (error) {
      alert('Error al guardar: ' + error.message)
    } else {
      alert('Solicitud de acceso guardada ✅')
      setLocked(true)
    }
  }

  if (loading) return <p className="p-4">Cargando solicitud...</p>

  return (
    <div className="space-y-4 border p-4 rounded">
      <h2 className="text-xl font-semibold">🖥️ Solicitud de Acceso a Sistemas</h2>

      <div>
        <label className="block mb-1">Rol deseado</label>
        <select
          value={role}
          onChange={(e) => setRole(e.target.value)}
          disabled={locked}
          className="w-full border px-3 py-2 rounded"
        >
          <option value="">Seleccionar</option>
          <option value="Supervisor">Supervisor</option>
          <option value="Clinician">Clinician</option>
          <option value="Biller">Biller</option>
          <option value="TCM">TCM</option>
          <option value="RBT">RBT</option>
          <option value="Admin">Admin</option>
          <option value="Otro">Otro</option>
        </select>
      </div>

      <div>
        <label className="block mb-1">Acción requerida</label>
        <select
          value={action}
          onChange={(e) => setAction(e.target.value)}
          disabled={locked}
          className="w-full border px-3 py-2 rounded"
        >
          <option value="">Seleccionar</option>
          <option value="Add">Agregar</option>
          <option value="Deactivate">Desactivar</option>
          <option value="Reactivate">Reactivar</option>
          <option value="Update">Actualizar</option>
        </select>
      </div>

      <div>
        <label className="block mb-1">Firma del supervisor (opcional)</label>
        <input
          type="text"
          value={supervisorApproval}
          onChange={(e) => setSupervisorApproval(e.target.value)}
          disabled={locked}
          className="w-full border px-3 py-2 rounded"
          placeholder="RRHH completará esto más adelante"
        />
      </div>

      {!locked && (
        <button
          onClick={handleSave}
          className="bg-blue-600 text-white px-4 py-2 rounded"
        >
          Enviar solicitud
        </button>
      )}

      {locked && <p className="text-green-600">✅ Solicitud registrada</p>}
    </div>
  )
}