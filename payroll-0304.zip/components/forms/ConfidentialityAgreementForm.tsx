'use client'

import { useEffect, useState } from 'react'
import { useSession } from 'next-auth/react'
import { supabase } from '@/lib/supabase'

interface Props {
  employeeId: string
}

export default function ConfidentialityAgreementForm({ employeeId }: Props) {
  const { data: session } = useSession()
  const [signature, setSignature] = useState('')
  const [signedDate, setSignedDate] = useState('')
  const [locked, setLocked] = useState(false)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetch = async () => {
      const { data } = await supabase
        .from('confidentiality_agreements')
        .select('signature, signed_date')
        .eq('employee_id', employeeId)
        .single()

      if (data) {
        setSignature(data.signature || '')
        setSignedDate(data.signed_date || '')
        if (data.signature && data.signed_date) setLocked(true)
      }

      setLoading(false)
    }

    fetch()
  }, [employeeId])

  const handleSave = async () => {
    const today = new Date().toISOString().split('T')[0]

    const { error } = await supabase
      .from('confidentiality_agreements')
      .upsert({
        employee_id: employeeId,
        signature,
        signed_date: today,
      }, { onConflict: ['employee_id'] })

    if (error) {
      alert('Error al guardar: ' + error.message)
    } else {
      setSignedDate(today)
      setLocked(true)
      alert('✅ Acuerdo de confidencialidad firmado correctamente.')
    }
  }

  if (loading) return <p className="p-4">Cargando acuerdo...</p>

  return (
    <div className="space-y-4 border p-4 rounded">
      <h2 className="text-xl font-semibold">📄 Acuerdo de Confidencialidad</h2>

      <p className="text-sm text-gray-700">
        Por la presente, me comprometo a no divulgar información confidencial sobre pacientes,
        usuarios o empleados de DTT Coaching Services. Entiendo que cualquier incumplimiento
        podría resultar en acciones disciplinarias y/o consecuencias legales. Acepto cumplir con
        todas las políticas de privacidad y regulaciones aplicables, incluyendo HIPAA.
      </p>

      <div>
        <label className="block mb-1">Firma del empleado (escriba su nombre completo)</label>
        <input
          type="text"
          value={signature}
          onChange={(e) => setSignature(e.target.value)}
          disabled={locked}
          className="w-full border px-3 py-2 rounded"
        />
      </div>

      {locked && signedDate && (
        <p className="text-green-700">✅ Firmado el {signedDate}</p>
      )}

      {!locked && (
        <button
          onClick={handleSave}
          className="bg-blue-600 text-white px-4 py-2 rounded"
        >
          Firmar Acuerdo
        </button>
      )}
    </div>
  )
}