'use client'

import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'

interface Props {
  employeeId: string
}

export default function DirectDepositAuthorizationForm({ employeeId }: Props) {
  const [authorized, setAuthorized] = useState(false)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetch = async () => {
      const { data } = await supabase
        .from('direct_deposit_authorizations')
        .select('authorized')
        .eq('employee_id', employeeId)
        .single()

      if (data?.authorized) setAuthorized(true)
      setLoading(false)
    }

    fetch()
  }, [employeeId])

  const handleAuthorize = async () => {
    const { error } = await supabase
      .from('direct_deposit_authorizations')
      .upsert({ employee_id: employeeId, authorized: true }, { onConflict: ['employee_id'] })

    if (error) {
      alert('Error al registrar autorización')
    } else {
      setAuthorized(true)
      alert('✅ Autorización guardada correctamente')
    }
  }

  if (loading) return <p className="p-4">Cargando autorización...</p>

  return (
    <div className="space-y-4 border p-4 rounded">
      <h2 className="text-xl font-semibold">🏦 Autorización para Depósito Directo</h2>

      <p className="text-sm text-gray-700">
        Autorizo a DTT Coaching Services a depositar mis pagos directamente en la cuenta bancaria
        cuya información proporcioné mediante cheque void. Entiendo que puedo revocar esta autorización
        en cualquier momento mediante notificación por escrito.
      </p>

      {!authorized ? (
        <button
          onClick={handleAuthorize}
          className="bg-blue-600 text-white px-4 py-2 rounded"
        >
          Autorizo el depósito directo
        </button>
      ) : (
        <p className="text-green-600 font-medium">✅ Autorización registrada</p>
      )}
    </div>
  )
}