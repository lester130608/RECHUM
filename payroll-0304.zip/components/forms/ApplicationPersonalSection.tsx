'use client'

import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'
import { useSession } from 'next-auth/react'

interface Props {
  employeeId: string
}

export default function ApplicationPersonalSection({ employeeId }: Props) {
  const { data: session } = useSession()
  const [form, setForm] = useState({
    full_name: '',
    address: '',
    phone: '',
    has_license: false,
    felony: '',
    desired_position: '',
    availability: '',
    start_date: '',
    special_skills: '',
  })

  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchData = async () => {
      const { data, error } = await supabase
        .from('employment_applications')
        .select('*')
        .eq('employee_id', employeeId)
        .single()

      if (data) setForm(data)
      setLoading(false)
    }

    fetchData()
  }, [employeeId])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type, checked } = e.target
    setForm((prev) => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }))
  }

  const handleSubmit = async () => {
    const { error } = await supabase.from('employment_applications').upsert({
      ...form,
      employee_id: employeeId,
    }, { onConflict: ['employee_id'] })

    if (error) {
      alert('Error al guardar: ' + error.message)
    } else {
      alert('Datos personales guardados ✅')
    }
  }

  if (loading) return <p className="p-4">Cargando formulario...</p>

  return (
    <div className="space-y-4 border p-4 rounded">
      <h2 className="text-xl font-semibold">📝 Información Personal y Preferencia de Trabajo</h2>

      <div>
        <label className="block mb-1">Nombre completo</label>
        <input
          type="text"
          name="full_name"
          value={form.full_name}
          onChange={handleChange}
          className="w-full border px-3 py-2 rounded"
        />
      </div>

      <div>
        <label className="block mb-1">Dirección</label>
        <input
          type="text"
          name="address"
          value={form.address}
          onChange={handleChange}
          className="w-full border px-3 py-2 rounded"
        />
      </div>

      <div>
        <label className="block mb-1">Teléfono</label>
        <input
          type="text"
          name="phone"
          value={form.phone}
          onChange={handleChange}
          className="w-full border px-3 py-2 rounded"
        />
      </div>

      <div className="flex items-center gap-2">
        <input
          type="checkbox"
          name="has_license"
          checked={form.has_license}
          onChange={handleChange}
        />
        <label>Tengo licencia de conducir</label>
      </div>

      <div>
        <label className="block mb-1">¿Ha sido condenado por un delito grave?</label>
        <select
          name="felony"
          value={form.felony}
          onChange={handleChange}
          className="w-full border px-3 py-2 rounded"
        >
          <option value="">Seleccionar</option>
          <option value="no">No</option>
          <option value="yes">Sí</option>
        </select>
      </div>

      <div>
        <label className="block mb-1">Posición deseada</label>
        <input
          type="text"
          name="desired_position"
          value={form.desired_position}
          onChange={handleChange}
          className="w-full border px-3 py-2 rounded"
        />
      </div>

      <div>
        <label className="block mb-1">Horario preferido</label>
        <select
          name="availability"
          value={form.availability}
          onChange={handleChange}
          className="w-full border px-3 py-2 rounded"
        >
          <option value="">Seleccionar</option>
          <option value="full_time">Tiempo completo</option>
          <option value="part_time">Medio tiempo</option>
          <option value="per_diem">Por servicio (per diem)</option>
        </select>
      </div>

      <div>
        <label className="block mb-1">Fecha disponible para comenzar</label>
        <input
          type="date"
          name="start_date"
          value={form.start_date}
          onChange={handleChange}
          className="w-full border px-3 py-2 rounded"
        />
      </div>

      <div>
        <label className="block mb-1">Habilidades especiales</label>
        <textarea
          name="special_skills"
          value={form.special_skills}
          onChange={handleChange}
          className="w-full border px-3 py-2 rounded"
        />
      </div>

      <button
        onClick={handleSubmit}
        className="mt-4 bg-blue-600 text-white px-4 py-2 rounded"
      >
        Guardar sección
      </button>
    </div>
  )
}