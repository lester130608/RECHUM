'use client'

import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'

interface Props {
  employeeId: string
}

export default function ApplicationSignatureSection({ employeeId }: Props) {
  const [signature, setSignature] = useState('')
  const [signedDate, setSignedDate] = useState('')
  const [loading, setLoading] = useState(true)
  const [locked, setLocked] = useState(false)

  useEffect(() => {
    const fetch = async () => {
      const { data } = await supabase
        .from('employment_applications')
        .select('signature, signed_date')
        .eq('employee_id', employeeId)
        .single()

      if (data) {
        setSignature(data.signature || '')
        setSignedDate(data.signed_date || '')
        if (data.signature && data.signed_date) setLocked(true)
      }

      setLoading(false)
    }

    fetch()
  }, [employeeId])

  const handleSave = async () => {
    const { error } = await supabase
      .from('employment_applications')
      .update({
        signature,
        signed_date: signedDate,
      })
      .eq('employee_id', employeeId)

    if (error) {
      alert('Error al guardar firma')
    } else {
      alert('✅ Documento firmado correctamente')
      setLocked(true)
    }
  }

  if (loading) return <p className="p-4">Cargando...</p>

  return (
    <div className="space-y-4 border p-4 rounded">
      <h2 className="text-xl font-semibold">✍️ Firma del empleado</h2>

      <div>
        <label className="block mb-1">Firma (escriba su nombre completo)</label>
        <input
          type="text"
          value={signature}
          onChange={(e) => setSignature(e.target.value)}
          disabled={locked}
          className="w-full border px-3 py-2 rounded"
        />
      </div>

      <div>
        <label className="block mb-1">Fecha</label>
        <input
          type="date"
          value={signedDate}
          onChange={(e) => setSignedDate(e.target.value)}
          disabled={locked}
          className="w-full border px-3 py-2 rounded"
        />
      </div>

      {!locked && (
        <button
          onClick={handleSave}
          className="mt-4 bg-green-600 text-white px-4 py-2 rounded"
        >
          Finalizar y firmar
        </button>
      )}

      {locked && (
        <p className="text-green-700 font-medium">
          ✅ Documento firmado el {signedDate}
        </p>
      )}
    </div>
  )
}