'use client'

import { useState } from 'react'
import { supabase } from '@/lib/supabase'

interface UploadDocumentProps {
  employeeId: string
  type: string // ej: "license", "id", "w9"
}

export default function UploadDocument({ employeeId, type }: UploadDocumentProps) {
  const [file, setFile] = useState<File | null>(null)
  const [uploading, setUploading] = useState(false)
  const [message, setMessage] = useState('')

  const handleUpload = async () => {
    if (!file) return

    setUploading(true)
    setMessage('')

    const filePath = `employee-documents/${employeeId}/${type}-${Date.now()}-${file.name}`

    // Subir archivo al bucket
    const { data: uploadData, error: uploadError } = await supabase.storage
      .from('employee-documents')
      .upload(filePath, file)

    if (uploadError) {
      setMessage(`Error al subir archivo: ${uploadError.message}`)
      setUploading(false)
      return
    }

    // Crear URL firmada (válida por 1 año)
    const { data: urlData, error: urlError } = await supabase.storage
      .from('employee-documents')
      .createSignedUrl(filePath, 60 * 60 * 24 * 365)

    const fileUrl = urlData?.signedUrl

    if (!fileUrl || urlError) {
      setMessage('Error al obtener la URL del archivo')
      setUploading(false)
      return
    }

    // Guardar en tabla employee_documents
    const { error: dbError } = await supabase.from('employee_documents').insert({
      employee_id: employeeId,
      type,
      file_url: fileUrl,
      verified: false
    })

    if (dbError) {
      setMessage(`Archivo subido, pero error en base de datos: ${dbError.message}`)
    } else {
      setMessage('Archivo subido y guardado correctamente ✅')
    }

    setUploading(false)
  }

  return (
    <div className="space-y-2">
      <label className="block font-medium">Subir archivo para: {type}</label>
      <input
        type="file"
        onChange={(e) => setFile(e.target.files?.[0] || null)}
        className="border p-2 w-full"
      />
      <button
        onClick={handleUpload}
        disabled={!file || uploading}
        className="bg-blue-600 text-white px-4 py-2 rounded disabled:opacity-50"
      >
        {uploading ? 'Subiendo...' : 'Subir'}
      </button>
      {message && <p className="text-sm mt-2 text-gray-700">{message}</p>}
    </div>
  )
}