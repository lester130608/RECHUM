'use client'

import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'

interface EmployeeOnboardingChecklistProps {
  employeeId: string
}

type Checklist = {
  w9_uploaded: boolean
  id_uploaded: boolean
  license_uploaded: boolean
  direct_deposit_uploaded: boolean
  background_check_completed: boolean
  confidentiality_signed: boolean
  drug_test_signed: boolean
  agreement_signed: boolean
  handbook_acknowledged: boolean
  hipaa_training_completed: boolean
  osha_training_completed: boolean
  cultural_training_completed: boolean
  job_description_reviewed: boolean
  onboarding_complete: boolean
  verified_by: string | null
  verified_at: string | null
}

export default function EmployeeOnboardingChecklist({ employeeId }: EmployeeOnboardingChecklistProps) {
  const [checklist, setChecklist] = useState<Checklist | null>(null)
  const [loading, setLoading] = useState(true)

  const fetchChecklist = async () => {
    const { data, error } = await supabase
      .from('onboarding_checklist')
      .select('*')
      .eq('employee_id', employeeId)
      .single()

    if (error) {
      console.error('Error al cargar checklist:', error)
    } else {
      setChecklist(data)
    }

    setLoading(false)
  }

  useEffect(() => {
    fetchChecklist()
  }, [employeeId])

  if (loading) return <p>Cargando checklist...</p>
  if (!checklist) return <p>No se encontró información de onboarding.</p>

  const displayItem = (label: string, value: boolean) => (
    <li className="flex justify-between py-1 border-b">
      <span>{label}</span>
      <span className={value ? 'text-green-600' : 'text-red-600'}>
        {value ? '✅ Completado' : '⛔ Pendiente'}
      </span>
    </li>
  )

  return (
    <div className="space-y-4">
      <h2 className="text-lg font-semibold">Checklist de Onboarding</h2>
      <ul className="divide-y divide-gray-200">
        {displayItem('W-9 cargado', checklist.w9_uploaded)}
        {displayItem('ID cargado', checklist.id_uploaded)}
        {displayItem('Licencia cargada', checklist.license_uploaded)}
        {displayItem('Depósito directo cargado', checklist.direct_deposit_uploaded)}
        {displayItem('Antecedentes verificados', checklist.background_check_completed)}
        {displayItem('Acuerdo de confidencialidad firmado', checklist.confidentiality_signed)}
        {displayItem('Consentimiento de drogas firmado', checklist.drug_test_signed)}
        {displayItem('Acuerdo de servicios firmado', checklist.agreement_signed)}
        {displayItem('Manual del empleado reconocido', checklist.handbook_acknowledged)}
        {displayItem('Entrenamiento HIPAA', checklist.hipaa_training_completed)}
        {displayItem('Entrenamiento OSHA', checklist.osha_training_completed)}
        {displayItem('Cultural Competency', checklist.cultural_training_completed)}
        {displayItem('Descripción del puesto revisada', checklist.job_description_reviewed)}
      </ul>

      <div className="mt-4 font-bold">
        {checklist.onboarding_complete
          ? <p className="text-green-700">🎉 Onboarding COMPLETO</p>
          : <p className="text-yellow-700">⚠️ Onboarding INCOMPLETO</p>}
      </div>
    </div>
  )
}