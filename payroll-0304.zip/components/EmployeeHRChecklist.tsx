'use client'

import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'

interface Props {
  employeeId: string
  isEditable?: boolean // true si es RRHH, false si es el empleado solo visualiza
}

export default function EmployeeHRChecklist({ employeeId, isEditable = false }: Props) {
  const [checklist, setChecklist] = useState<any>({})
  const [loading, setLoading] = useState(true)

  const fields = [
    { key: 'resume', label: 'Resume o cartas de referencia' },
    { key: 'copy_of_id', label: 'Copia de ID / SS / Pasaporte' },
    { key: 'license', label: 'Licencias o certificaciones' },
    { key: 'npi', label: 'NPI' },
    { key: 'ahca_check', label: 'Background check AHCA (Nivel II)' },
    { key: 'w9', label: 'W-4 o W-9' },
    { key: 'i9', label: 'Formulario I-9' },
    { key: 'application_form', label: 'Solicitud de empleo' },
    { key: 'void_check', label: 'Void check o cuenta bancaria' }
  ]

  useEffect(() => {
    const fetchChecklist = async () => {
      const { data, error } = await supabase
        .from('onboarding_checklist')
        .select('*')
        .eq('employee_id', employeeId)
        .single()

      if (error) {
        console.error('Error al obtener checklist:', error)
      } else {
        setChecklist(data || {})
      }

      setLoading(false)
    }

    fetchChecklist()
  }, [employeeId])

  const handleChange = (key: string) => {
    setChecklist((prev: any) => ({
      ...prev,
      [key]: !prev[key]
    }))
  }

  const handleSave = async () => {
    const { error } = await supabase
      .from('onboarding_checklist')
      .upsert({ ...checklist, employee_id: employeeId }, { onConflict: ['employee_id'] })

    if (error) {
      alert('Error al guardar checklist')
    } else {
      alert('Checklist guardado correctamente ✅')
    }
  }

  if (loading) return <p className="p-4">Cargando checklist...</p>

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-semibold">📋 Checklist de Expediente</h2>
      <ul className="space-y-2">
        {fields.map((item) => (
          <li key={item.key} className="flex items-center gap-3">
            <input
              type="checkbox"
              checked={!!checklist[item.key]}
              onChange={() => handleChange(item.key)}
              disabled={!isEditable}
            />
            <label className="text-sm">{item.label}</label>
          </li>
        ))}
      </ul>

      {isEditable && (
        <button
          onClick={handleSave}
          className="mt-4 bg-blue-600 text-white px-4 py-2 rounded"
        >
          Guardar checklist
        </button>
      )}
    </div>
  )
}