'use client'

import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'

interface EmployeeDocumentsListProps {
  employeeId: string
}

interface DocumentRecord {
  id: string
  type: string
  file_url: string
  verified: boolean
  upload_date: string
}

export default function EmployeeDocumentsList({ employeeId }: EmployeeDocumentsListProps) {
  const [documents, setDocuments] = useState<DocumentRecord[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchDocuments = async () => {
      const { data, error } = await supabase
        .from('employee_documents')
        .select('*')
        .eq('employee_id', employeeId)
        .order('upload_date', { ascending: false })

      if (data) setDocuments(data)
      if (error) console.error('Error al obtener documentos:', error)
      setLoading(false)
    }

    fetchDocuments()
  }, [employeeId])

  if (loading) return <p>Cargando documentos...</p>

  return (
    <div className="space-y-4">
      <h2 className="text-lg font-semibold">Documentos cargados</h2>
      {documents.length === 0 ? (
        <p>No se han subido documentos aún.</p>
      ) : (
        <ul className="space-y-2">
          {documents.map((doc) => (
            <li key={doc.id} className="flex justify-between items-center border p-2 rounded">
              <div>
                <p className="font-medium">{doc.type}</p>
                <p className="text-sm text-gray-500">{new Date(doc.upload_date).toLocaleString()}</p>
              </div>
              <a
                href={doc.file_url}
                target="_blank"
                rel="noopener noreferrer"
                className="text-blue-600 underline"
              >
                Ver archivo
              </a>
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}